package org.cqipc.books.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.cqipc.books.bean.Tb_Books_Type;

public interface Tb_Books_TypeDao {
	public int addBookType(Tb_Books_Type booktype);

	public int modifyBookType(Tb_Books_Type booktype);

	public Tb_Books_Type findBookTypeById(int id);

	public List<Tb_Books_Type> findAllBookType();

	public int findBookTypePageCount();

	public List<Tb_Books_Type> findBookTypePage(

	@Param("pageCount") int pageCount, @Param("pageSize") int pageSize);
}