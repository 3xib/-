package org.cqipc.books.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.cqipc.books.bean.Tb_User;

public interface Tb_UserDao {
	public Tb_User userLogin(@Param("user") String user, @Param("passwd") String passwd);

	public int addUsers(Tb_User users);

	public int modifyPassword(@Param("id") int id, @Param("passwd") String passwd);

	public List<Tb_User> selectUserAll();

	public int removeUser(int id);

	public int modifyPasswordByRoot(@Param("username") String username, @Param("passwd") String passwd);

	public int findUserNames(String username);

}