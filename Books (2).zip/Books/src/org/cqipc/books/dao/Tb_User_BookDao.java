package org.cqipc.books.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.cqipc.books.bean.Tb_User_Book;

public interface Tb_User_BookDao {
	public int addUserBooks(Tb_User_Book tub);

	public int removeUserBooks(int id);

	public List<Tb_User_Book> findUserBookByUid(@Param("uid") int uid, @Param("pageCount") int pageCount,
			@Param("pageSize") int pageSize);

	public int findUserBookByUidCount(int uid);

	public List<Tb_User_Book> findUserBookByBid(@Param("bid") int bid, @Param("pageCount") int pageCount,
			@Param("pageSize") int pageSize);

	public int findUserBookByBidCount(int bid);

	public List<Tb_User_Book> findAllUserBook(@Param("pageCount") int pageCount, @Param("pageSize") int pageSize);

	public int findAlIUserBookCount();

	public int modifyStat(@Param("id") int id);

	public int findBookUseByBid(int bid);

	public List<Tb_User_Book> searchUserBooksPage(
			@Param("uid") int uid, 
			@Param("bid") int bid,
			@Param("btime") String btime,
			@Param("etime") String etime, 
			@Param("endTime") String endTime,
			@Param("stat") int stat, 
			@Param("pageCount") int pageCount, 
			@Param("pageSize") int pageSize);

	public int searchUserBooksPageount(
			@Param("uid") int uid, 
			@Param("bid") int bid, 
			@Param("btime") String btime,
			@Param("etime") String etime, 
			@Param("endTime") String endTime,
			@Param("stat") int stat);

	public int findLendBookFlag(int bid);

	public int findAllUserBookCount();

	public int searchUserBooksPageCount(int uid, int bid, String btime, String etime, String endTime, int stat);
}
