package org.cqipc.books.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.cqipc.books.bean.Tb_Books;

public interface Tb_BooksDao {
	public int addBooks(Tb_Books tb);

	public int modifyBooks(Tb_Books tb);

	public int removeBooks(int id);

	public Tb_Books findBooksById(int id);

	public List<Tb_Books> findAllBooksPage(@Param("pageCount") int pageCount, @Param("pageSize") int pageSize);

	public int selectBooksCount();

	public List<Tb_Books> selectBooksAll();
}
