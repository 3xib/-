package org.cqipc.books.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class BaseDao<T> {
	private SqlSessionFactory sqlSessionFactory;
	protected SqlSession sqlSession;
	private Class<T> mapper;
	
	public BaseDao() {
		initSqlSessionFactory();
		sqlSession=sqlSessionFactory.openSession(true);
	}

	public T getMapper() {
		return sqlSession.getMapper(mapper);
	}

	public void setMapper(Class<T> mapper) {
		this.mapper = mapper;
	}

	private void initSqlSessionFactory() {
		InputStream is=null;
		try {
			is=Resources.getResourceAsStream("MyBatis.xml");
		} catch (IOException e) {
			e.printStackTrace();
		}
		sqlSessionFactory=new SqlSessionFactoryBuilder().build(is);
	}

	public int findAllUserBookCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int searchUserBooksPageCount(int uid, int bid, String btime, String etime, String endTime, int stat) {
		// TODO Auto-generated method stub
		return 0;
	}
}
